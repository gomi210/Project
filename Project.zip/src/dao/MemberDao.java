package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.MemberDto;

public class MemberDao {
	Connection getConnection() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String id = "test0101";	
		String pw = "test0101";	
		
		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, id, pw);
		
		return conn;
	}
	
	public boolean loginCheck(String id, String pw) throws Exception {
		Connection conn = getConnection();
		String sql = "SELECT count(*) FROM member WHERE id = ? AND pw = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		ResultSet rs = pstmt.executeQuery();
		int result = 0;	
		if(rs.next()) {
			result = rs.getInt(1);	
		}
		
		rs.close();
		pstmt.close();
		conn.close();
		
		return result==1;
	}
	
	
	public void registerMember(String id, String pw, String name) throws Exception {
		Connection conn = getConnection();
		String sql = "INSERT INTO member(id, pw, name) VALUES(?, ?, ?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		pstmt.setString(3, name);
		
		pstmt.executeUpdate();
		
		pstmt.close();
		conn.close();
	}
	
	public MemberDto getMemberInfo(String id) throws Exception {
	    Connection conn = getConnection();
	    String sql = "SELECT id, pw, name, point FROM member WHERE id = ?"; // SQL 쿼리에서 물음표 사용
	    PreparedStatement pstmt = conn.prepareStatement(sql);
	    pstmt.setString(1, id); 
	    ResultSet rs = pstmt.executeQuery();
	    
	    MemberDto mDto = null;
	    if (rs.next()) {
	        String pw = rs.getString("pw");   
	        String name = rs.getString("name");   
	        int point = rs.getInt("point");   
	        mDto = new MemberDto(id, pw, name, point);  
	    }
	    
	    rs.close();
	    pstmt.close();
	    conn.close();
	    
	    return mDto;
	}
	
	public ArrayList<MemberDto> getMemberList() throws Exception {
		Connection conn = getConnection();
		ArrayList<MemberDto> listRet = new ArrayList<MemberDto>();
		
		String sql = "SELECT id, pw, name, point FROM member"; // SQL 쿼리에서 물음표 사용
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		
		while (rs.next()) {
			String id = rs.getString("id");   
			String pw = rs.getString("pw");   
			String name = rs.getString("name");   
			int point = rs.getInt("point");   
			MemberDto mDto = new MemberDto(id, pw, name, point);
			listRet.add(mDto);
		}
		
		rs.close();
		pstmt.close();
		conn.close();
		
		return listRet;
	}
	
    // 특정 ID의 회원 정보를 삭제
    public boolean deleteMember(String id) throws Exception {
        Connection conn =getConnection();
        PreparedStatement pstmt = null;
        boolean isDeleted = false;

        try {
            String sql = "DELETE FROM member WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                isDeleted = true;
            }
        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return isDeleted;
    }
	
}
