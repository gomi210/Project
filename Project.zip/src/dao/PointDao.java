package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PointDao {
	Connection getConnection() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String id = "test0101";	
		String pw = "test0101";	
		
		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, id, pw);
		
		return conn;
	}
	
	// 사용자 포인트 조회
    public int getPoints(String id) throws Exception {
        Connection conn = getConnection();
        String sql = "SELECT point FROM member WHERE id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id);
        ResultSet rs = pstmt.executeQuery();
        int points = 0;
        if (rs.next()) {
            points = rs.getInt("point");
        }
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return points;
    }
    
    // 사용자 포인트 업데이트
	public boolean updatePoints(String id, int points) throws Exception {
        Connection conn = getConnection();
        String sql = "UPDATE member SET point = point - ? "
        			+ " WHERE id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, points);
        pstmt.setString(2, id);
        int rowsAffected = pstmt.executeUpdate();
        
        pstmt.close();
        conn.close();
        
        return rowsAffected > 0;
    }
	
    public void updateMemberPoints(String id, int points) throws Exception {
        Connection conn = getConnection();
        String sql = "UPDATE member SET point = point + ? WHERE id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, points);
        pstmt.setString(2, id);
        pstmt.executeUpdate();

        pstmt.close();
        conn.close();
    }
}
