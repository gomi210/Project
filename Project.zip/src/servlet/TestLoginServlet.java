package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDao;

@WebServlet("/TestLoginServlet")
public class TestLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("id: " + id + ", pw: " + pw);
		MemberDao mDao = new MemberDao();
		boolean result = false;
		try {
			result = mDao.loginCheck(id, pw);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result) {
			// Main.jsp로 이동
			HttpSession session = request.getSession();
			session.setAttribute("id", id);	// (key, value)
			
			// id가 "admin"인 경우 admin.jsp로 이동
            if ("admin".equals(id)) {
                response.sendRedirect("admin.jsp");
            } else {
                // 그렇지 않으면 MainPage.jsp로 이동
                RequestDispatcher rd = request.getRequestDispatcher("MainPage.jsp");
                rd.forward(request, response);
            }
		} else {
			request.setAttribute("loginFailed", true);
            request.setAttribute("loginFailedMessage", "아이디/비밀번호를 다시 확인하세요");			
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.forward(request, response);
		}
	}

}
