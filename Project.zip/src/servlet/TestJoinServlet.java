package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDao;

@WebServlet("/TestJoinServlet")
public class TestJoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		System.out.println("요청들어옴.");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		System.out.println("id: " + id + ", pw: " + pw + ", name: " + name);
		
		MemberDao mDao = new MemberDao();
		boolean result = false;
		try {
			mDao.registerMember(id, pw, name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("Success", true);
        request.setAttribute("SuccessMessage", "가입되었습니다. 로그인 해주세요");			
		RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
		rd.forward(request, response);
	}

}
