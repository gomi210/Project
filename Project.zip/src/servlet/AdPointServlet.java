package servlet;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PointDao;

@WebServlet("/AdPointServlet")
public class AdPointServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        Random rand = new Random();
        int points = rand.nextInt(1000) + 1; // 1 to 1000 points

        PointDao pDao = new PointDao();
        try {
            pDao.updateMemberPoints(id, points);
            response.getWriter().write(String.valueOf(points));
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("포인트 적립 중 오류가 발생했습니다.");
        }
    }
}
