package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PointDao;

@WebServlet("/UpdatePointServlet")
public class UpdatePointServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        int requestedPoints = Integer.parseInt(request.getParameter("points"));

        PointDao pDao = new PointDao();
        int currentPoints = 0;
        boolean success = false;

        try {
            currentPoints = pDao.getPoints(id);

            if (currentPoints >= requestedPoints) {
                success = pDao.updatePoints(id, requestedPoints);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        
        if (currentPoints >= requestedPoints) {
            if (success) {
                response.getWriter().write("포인트가 업데이트 되었습니다.");
            } else {
                response.getWriter().write("포인트 업데이트에 실패했습니다.");
            }
        } else {
            response.getWriter().write("포인트가 부족합니다. 광고를 클릭하세요.");
        }
    }
}
