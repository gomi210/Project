package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

@WebServlet("/AjaxAchooServlet")
public class AjaxAchooServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String str = request.getParameter("str");
		
		System.out.println("요청 들어옴 str=" + str);
		
		
		// 응답 --> JSON(또는 JSON ARRAY)
		response.setContentType("application/json; charset=utf-8");
		JSONObject obj = new JSONObject();	// json-simple / Jackson / ... 3가지 자주 쓰는데 여기서는 json-simple씀
		obj.put("data", str+str);
		PrintWriter writer = response.getWriter();
		writer.print(obj);
	}

}
