package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDao;

@WebServlet("/TestDeleteMemberServlet")
public class TestDeleteMemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("memberId");
        MemberDao mDao = new MemberDao();

        boolean isDeleted = false;
        try {
            isDeleted = mDao.deleteMember(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (isDeleted) {
            response.getWriter().write("삭제되었습니다.");
        } else {
            response.getWriter().write("삭제 실패.");
        }
    }
}
